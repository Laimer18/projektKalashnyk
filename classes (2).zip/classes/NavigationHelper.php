<?php

class NavigationHelper
{
    // Отримати URL особистого кабінету або реєстрації в залежності від сесії
    public static function getAccountUrl(string $basePath = '/projekt1'): string
    {
        $userId = $_SESSION['user_id'] ?? null;
        $sessionId = session_id() ?: 'NO_ACTIVE_SESSION';
        error_log("NavigationHelper::getAccountUrl - user_id: " . ($userId ?? 'NOT SET') . " | Session ID: $sessionId");

        return $userId !== null
            ? $basePath . '/user/personal_page'
            : $basePath . '/register';
    }

    // Отримати повний URL для ресурсів (assets) за відносним шляхом
    public static function getAssetUrl(string $relativePath, string $baseProjectPath = '/projekt1'): string
    {
        $relativePath = ltrim($relativePath, '/');

        if ($baseProjectPath !== '' && substr($baseProjectPath, -1) !== '/') {
            $baseProjectPath .= '/';
        } elseif ($baseProjectPath === '') {
            $baseProjectPath = '/';
        }

        return $baseProjectPath . $relativePath;
    }

    // Додатковий метод: URL домашньої сторінки
    public static function getHomeUrl(string $basePath = '/projekt1'): string
    {
        return $basePath . '/';
    }
}
