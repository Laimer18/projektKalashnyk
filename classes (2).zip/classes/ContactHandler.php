<?php
class ContactHandler
{
    private PDO $pdo;
    private array $data = [
        'first_name' => '',
        'last_name'  => '',
        'email'      => '',
        'phone'      => '',
        'question'   => ''
    ];
    private string $errorMessage = '';
    private string $successMessage = '';

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function handleForm(array $postData): bool
    {
        // Зберігаємо дані з форми, обрізаючи пробіли
        $this->data = [
            'first_name' => trim($postData['first_name'] ?? ''),
            'last_name'  => trim($postData['last_name'] ?? ''),
            'email'      => trim($postData['email'] ?? ''),
            'phone'      => trim($postData['phone'] ?? ''),
            'question'   => trim($postData['questions'] ?? '')
        ];

        if (!$this->validate()) {
            return false;
        }

        // Виконуємо SQL-запит із використанням асоціативного масиву $this->data
        $sql  = "INSERT INTO contacts (first_name, last_name, email, phone, question, created_at)
                 VALUES (:first_name, :last_name, :email, :phone, :question, NOW())";
        $stmt = $this->pdo->prepare($sql);
        if ($stmt->execute($this->data)) {
            $this->successMessage = 'Your message has been sent successfully! We will contact you soon.';
            return true;
        }

        $this->errorMessage = 'An error occurred while sending the message. Please try again later.';
        return false;
    }

    private function validate(): bool
    {
        // Якщо хоча б одне з полів порожнє
        if (in_array('', $this->data, true)) {
            $this->errorMessage = 'All fields are required.';
            return false;
        }
        if (!filter_var($this->data['email'], FILTER_VALIDATE_EMAIL)) {
            $this->errorMessage = 'Invalid email format.';
            return false;
        }
        return true;
    }

    public function getErrorMessage(): string
    {
        return $this->errorMessage;
    }

    public function getSuccessMessage(): string
    {
        return $this->successMessage;
    }

    // За потреби можна отримати всі дані форми
    public function getData(): array
    {
        return $this->data;
    }
}