<?php

class SessionManager
{
    private static ?SessionManager $instance = null;

    private function __construct()
    {
        $this->start();
    }

    private function __clone() {}

    public function __wakeup()
    {
        throw new \Exception("Cannot unserialize a Singleton");
    }

    public static function getInstance(): SessionManager
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function start(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public function login($user): void
    {
        $_SESSION['user'] = [
            'id' => $user->getId(),
            'email' => $user->getEmail()
        ];

        error_log("SessionManager::login - User ID: {$user->getId()} | Session ID: " . session_id());

        try {
            $pdo = Database::getInstance();
            $cookieConsentRepo = new CookieConsentRepository($pdo);
            $consentStatus = $cookieConsentRepo->getUserConsentStatus($user->getId());
            $_SESSION['user_cookie_consent_status'] = $consentStatus ?? 'pending';
        } catch (Exception $e) {
            $_SESSION['user_cookie_consent_status'] = 'pending';
        }
    }

    public function logout(): void
    {
        if (session_status() !== PHP_SESSION_NONE) {
            session_destroy();
            $_SESSION = [];
        }
    }

    public function isLoggedIn(): bool
    {
        return isset($_SESSION['user']);
    }

    public function getUser(): ?array
    {
        return $_SESSION['user'] ?? null;
    }

    public function getUserId(): ?int
    {
        return $_SESSION['user']['id'] ?? null;
    }

    public function set(string $key, $value): void
    {
        $_SESSION[$key] = $value;
    }

    public function get(string $key)
    {
        return $_SESSION[$key] ?? null;
    }

    public function remove(string $key): void
    {
        unset($_SESSION[$key]);
    }
}
