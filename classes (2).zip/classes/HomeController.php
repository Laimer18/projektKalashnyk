<?php

class HomeController
{
    public function index(): void
    {
        $galleryItems = $this->getGalleryData();

        $statusMessage = '';
        $statusType = '';

        if (isset($_SESSION['contact_form_status'])) {
            $status = $_SESSION['contact_form_status'];

            if (is_array($status)) {
                $statusMessage = htmlspecialchars($status['message'] ?? 'An unexpected error occurred.');
                $statusType = !empty($status['success']) ? 'success' : 'error';
            } else {
                $statusType = $status === 'success' ? 'success' : 'error';
                $statusMessage = $status === 'success'
                    ? 'Form submitted successfully.'
                    : 'An error occurred while submitting the form.';
            }
            unset($_SESSION['contact_form_status']);
        }

        $viewPath = __DIR__ . '/../views/main_page_view.php';
        if (file_exists($viewPath)) {
            require $viewPath;
        } else {
            http_response_code(500);
            echo "<h1>500 - Server Error</h1><p>The main page template is missing. Please contact support.</p>";
            error_log("HomeController: Main page view not found at $viewPath");
        }
    }

    private function getGalleryData(): array
    {
        $baseImagePath = NavigationHelper::getAssetUrl('images/gallery/');
        $galleryData = [];

        for ($i = 1; $i <= 9; $i++) {
            $filename = "g{$i}.jpg";
            $galleryData[] = [
                'url' => htmlspecialchars($baseImagePath . $filename),
                'thumbnail_url' => htmlspecialchars($baseImagePath . $filename),
                'title' => "Image $i"
            ];
        }

        return $galleryData;
    }
}
